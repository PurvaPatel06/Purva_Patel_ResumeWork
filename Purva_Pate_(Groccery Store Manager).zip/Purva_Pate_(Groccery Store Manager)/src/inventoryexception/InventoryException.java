package inventoryexception;

public class InventoryException extends Exception {
    public InventoryException(String message) {
        super(message);
    }
  
}
