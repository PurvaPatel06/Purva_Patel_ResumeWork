// Import the GroceryStore class from the grocerystore package
import grocerystore.GroceryStore;

// Main class for testing the Inventory App
public class TestInventoryApp {
    public static void main(String[] args) throws Exception {
        // Create an instance of the GroceryStore class
        GroceryStore gc = new GroceryStore();
        
        // Call the operationsMenu method to initiate the inventory operations
        gc.operationsMenu();
    }
}