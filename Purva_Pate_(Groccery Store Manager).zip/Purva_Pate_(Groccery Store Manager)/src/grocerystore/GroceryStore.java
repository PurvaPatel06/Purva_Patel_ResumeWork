// Define the package for the GroceryStore class
package grocerystore;

import java.util.Scanner;
import inventoryexception.InventoryException;
import inventorymanager.InventoryManager;

// Class representing a Grocery Store
public class GroceryStore {
    // Scanner for user input
    Scanner input = new Scanner(System.in);

    // Inventory Manager instance for managing inventory operations
    InventoryManager im = new InventoryManager();

    // Flag to control comments in purchaseItems method
    boolean comment = true;

    // Initial inventory data
    String[][] inventory = {
            {"Broccoli", "14"},
            {"Sausage", "35"},
            {"Bread", "20"},
            {"Tortilla", "40"},
            {"Eggs", "48"}
    };

    // Method to display the current inventory
    public void displayInventory() {
        for (int i = 0; i < inventory.length; i++) {
            System.out.println(inventory[i][0] + ":" + inventory[i][1]);
        }
    }

    // Method for purchasing items
    public void purchaseItems() {
        try {
            
            if (comment) {
                System.out.print("Enter item name to purchase or 'exit' to exit:");
                String item = input.next();

                if (item.equalsIgnoreCase("exit")) {
                    comment = false;
                    
                }else{

                int i = im.findItemIndex(inventory, item.toUpperCase());
                if (i < 0 || i > 4) {
                    System.out.println("Invalid input. Please try again");
                } else {
                    System.out.print("Enter the quantity to purchase:");
                    int num1 = input.nextInt();

                    if (num1 <= 0) {
                        throw new InventoryException("Invalid input: The desired amount is zero or less than zero");
                    } else if (num1 > Integer.valueOf(inventory[i][1])) {
                        throw new InventoryException("Not enough stock available. Please choose a smaller quantity");
                    } else {
                        im.updateInventory(inventory, i, -num1);
                        
                    }}
                }
            }
        } catch (ArithmeticException ae) {
            System.err.println(ae.getMessage());
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }finally{
            comment = true;
        }
    }

    // Method for restocking items
    public void restockItems() {
        try {
            String item;
            System.out.print("Enter item name to restock or 'exit' to exit:");
            item = input.next();
            if (item.equalsIgnoreCase("exit")) {
                comment = false;
                
            }else{
            int i = im.findItemIndex(inventory, item.toUpperCase());
            if (i < 0 || i > 4) {
                System.out.println("Invalid item name. Please try again.");
            } else {
                System.out.print("Enter the quantity to restock:");
                int num1 = input.nextInt();
                im.updateInventory(inventory, i, num1);
                
            }}
        } catch (ArithmeticException ae) {
            System.err.println(ae.getMessage());
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        finally{
            comment = true;
        }
    }

    // Method to manage inventory operations based on user input
    public void manageInventory(int j) {
        switch (j) {
            case 1:
                purchaseItems();
                operationsMenu();
                break;
            case 2:
                restockItems();
                operationsMenu();
                break;
            case 3:
                System.out.println("...exiting...bye...");
                break;
        }
    }

    // Method to display the main operations menu
    public void operationsMenu() {
        displayInventory();
        System.out.println("Menu:\r\n" +
                "\r\n" +
                "1. Purchase items\r\n" +
                "\r\n" +
                "2. Restock items\r\n" +
                "\r\n" +
                "3. Exit\r\n" +
                "\r\n" +
                "Choose an option:");

        // Flag to control user input validation
        boolean validInput = true;

        while (validInput) {
            if (input.hasNextInt()) {
                int num2 = input.nextInt();

                if (num2 < 1 || num2 > 3) {
                    System.out.println("Invalid input. Try again between 1, 2, 3:");
                    System.out.println("Menu:\r\n" +
                            "\r\n" +
                            "1. Purchase items\r\n" +
                            "\r\n" +
                            "2. Restock items\r\n" +
                            "\r\n" +
                            "3. Exit\r\n" +
                            "\r\n" +
                            "Choose an option:");
                } else {
                    validInput = false;
                    manageInventory(num2);
                }
            } 
        }

        
    }
}
