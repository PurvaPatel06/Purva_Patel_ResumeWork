// Define the package for the InventoryManager class
package inventorymanager;

// Class responsible for managing inventory operations
public class InventoryManager {

    // Method to find the index of an item in the inventory
    public final static int findItemIndex(String[][] items, String str){
        // Iterate through the items array
        int i;
        for(i = 0; i < items.length; i++ ){
            // Check if the item name matches (case-insensitive)
            if (items[i][0].toUpperCase().equals(str.toUpperCase())){
                // Return the index if found
                return i;
            }
        }
        // Return the length of the array if the item is not found
        return i;
    }

    // Method to update the inventory quantity after a purchase
    public final static void updateInventory(String[][] items, int x, int y ){
        // Retrieve the current quantity of the item
        int z = Integer.valueOf(items[x][1]);
        // Update the quantity by adding the purchased quantity
        items[x][1] = String.valueOf(z + y);
        // Display a success message
        System.out.println("Purchase successful! Updated Inventory");
    }
}