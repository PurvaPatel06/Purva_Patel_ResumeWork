public class CityFacility{
private String[] datas = new String[16];
private static final String[] header = {"Record","English entity","French entity","English Building","French Building","English building type","French building type","English building element","French building element","English building element type","French building element type","English facility group","French facility group","Subtype","Year built","Ownership"};
public CityFacility(String[] datas){
    this.datas = datas;
}
public String toString(){
for(int i=0; i<87; i = Integer.valueOf(datas[i])){
    String s = header[i];
    String p = datas [i];
    System.out.println(s + ":" + p);
}
return "";

    
}
public string CSVReader(String str){
    int start = 0;
    int end = str.indexOf(",");
    for(start = 0;start<end;){
        

    }


}



}