/**

*Program: CET Level 2


*Student Name: Purva Patel

*Student Number:041094311

*Course: CST8132_310 OOP

*Professor: James Mwangi PhD.

*/
import java.util.Scanner;
public abstract class Management implements Employee{
    private int employeeID;
    private String firstName;
    private String lastName;
    private double yearlySalary;
    

    public Management(){

    }
    public Management(String firstName, String lastName, int employeeID, double yearlySalary){
        this.employeeID = employeeID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.yearlySalary = yearlySalary;
    }
    /**
     * @return int return the employeeID
     */
    public int getEmployeeID() {
        return employeeID;
    }

    /**
     * @param employeeID the employeeID to set
     */
    public void setEmployeeID(int employeeID) {
        this.employeeID = employeeID;
    }

    /**
     * @return String return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return String return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return double return the yearlySalary
     */
    public double getYearlySalary() {
        return yearlySalary;
    }

    /**
     * @param yearlySalary the yearlySalary to set
     */
    public void setYearlySalary(double yearlySalary) {
        this.yearlySalary = yearlySalary;
    }
   public String toString(){
        return "Employee ID: " + employeeID 
        + "\n" + "Employee Name:" + firstName + lastName
        + "\n" + "Yearly Salary: " + yearlySalary;
    }
    
    public void addEmployee(Scanner input){
        System.out.print("Enter Employee ID: ");
        this.employeeID = input.nextInt();
        input.nextLine(); // Consume newline left-over
        System.out.print("Enter First Name: ");
        this.firstName = input.nextLine();
        System.out.print("Enter Last Name: ");
        this.lastName = input.nextLine();
        System.out.print("Enter Yearly Salary: ");
        this.yearlySalary = input.nextDouble();
    }

}