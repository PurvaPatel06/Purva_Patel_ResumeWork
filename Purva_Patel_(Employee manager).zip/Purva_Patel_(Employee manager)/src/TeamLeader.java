import java.util.Scanner;
public class TeamLeader extends Management {
    private String teamName;

    public TeamLeader() {
    }

    public TeamLeader(String firstName, String lastName, int employeeID, double yearlySalary, String teamName) {
        super(firstName, lastName, employeeID, yearlySalary);
        this.teamName = teamName;
    }
    public String toString() {
        
        return "Employee ID: " + super.getEmployeeID()
        + "\n" + "Employee Name:" + super.getFirstName() + super.getLastName()
        + "\n" + "Yearly Salary: " + super.getYearlySalary()+"\n"+ "Team Name: " + teamName;
    }
    public void addEmployee(Scanner input) {
        super.addEmployee(input);
        System.out.println("Enter Team Name: ");
        this.teamName = input.nextLine();
    }
}
