/**

*Program: CET Level 2


*Student Name: Purva Patel

*Student Number:041094311

*Course: CST8132_310 OOP

*Professor: James Mwangi PhD.

*/
import java.util.Scanner;
public class EMSDriver {
    
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem();
        Scanner scanner = new Scanner(System.in);
        char choice;
    do{
        System.out.println("Welcome to the Emloyee Management System"
        +"\nr: Read a list of employees from the CSV file"
        +"\na: Add a new employee"
        +"\np: Print the info of all the employees"
        +"\nm: Run monthly payroll"
        +"\nq: Quit"
        +"\n"
        +"\nEnter your option: ");
        choice = scanner.next().charAt(0);
        scanner.nextLine();
        switch (choice) {
            case 'r':
                ems.readEmployeesFromCsvFile("C:\\Users\\lenovo\\Downloads\\Purva_Patel_lab05\\Employee.csv"); // Call method to read employees from CSV
                break;
            case 'a':
                ems.addEmployee(scanner); // Call method to add a new employee
                break;
            case 'p':
                ems.printEmployeeDetails(); // Call method to print employee details
                break;
            case 'm':
                ems.monthlyPayroll(); // Call method to run monthly payroll
                break;
            case 'q':
                System.out.println("Successfully exited the program.");
                scanner.close();
                break;
                
            default:
                System.out.println("Invalid option. Please try again.");
        }
    } while (choice != 'q');
       
       
    
    }
    
}