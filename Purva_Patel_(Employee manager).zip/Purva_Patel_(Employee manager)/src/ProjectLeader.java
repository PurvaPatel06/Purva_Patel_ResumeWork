

/**

*Program: CET Level 2


*Student Name: Purva Patel

*Student Number:041094311

*Course: CST8132_310 OOP

*Professor: James Mwangi PhD.

*/

import java.util.Scanner;
public class ProjectLeader extends Management {
private String projectName;
public  ProjectLeader(){

}    
public ProjectLeader(String firstName, String lastName, int employeeID, double yearlySalary, String projectName){
super(firstName,lastName,employeeID,yearlySalary);
this.projectName = projectName;
}
public String toString(){
    
    return "Employee ID: " + super.getEmployeeID()
    + "\n" + "Employee Name:" + super.getFirstName() + super.getLastName()
    + "\n" + "Yearly Salary: " + super.getYearlySalary()+"\n"+
    "Project Name: " + projectName;
}


public void addEmployee(Scanner input) {
    System.out.print("Enter Employee ID: ");
        super.addEmployee(input);
    System.out.println("Enter Project Name: ");
    this.projectName = input.nextLine();
}
}