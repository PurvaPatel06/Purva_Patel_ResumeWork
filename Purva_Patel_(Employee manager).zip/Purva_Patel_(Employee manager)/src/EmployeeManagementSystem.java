/*
 * Assessment: lab 05
 * 
 * Due Date: 03/18/2022
 * Description: lab 05 is mainly focusing on inhertance and File I\O
 * Professor Name: James Mwangi PhD.
 */

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;
public class EmployeeManagementSystem {
    ArrayList<Management> employeeList = new  ArrayList<>();
    public EmployeeManagementSystem(){
       
    }
    public String[] readEmployeesFromCsvFile(String filePath){

        filePath = "C:\\Users\\lenovo\\Downloads\\Purva_Patel_lab05\\Employee.csv";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))){
            br.readLine();
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = CsvFileReader.lineReader(line);
                String firstName = values[0];
                String lastName = values[1];
                int employeeID = Integer.parseInt(values[2]);
                String designation = values[3];
                double yearlySalary = Double.parseDouble(values[4]);
                Management employee = null;
                if (designation.equalsIgnoreCase("Project Leader")){
                    employee = new ProjectLeader(firstName, lastName, employeeID, yearlySalary, values[5]);
                } else if (designation.equalsIgnoreCase("Team Leader")){
                    employee = new TeamLeader(firstName, lastName, employeeID, yearlySalary, values[6]);
                }
                employeeList.add(employee);

            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        int size = employeeList.size();
        String[] stringArray = new String[size];
        for (int i = 0; i < size; i++) {
            stringArray[i] = employeeList.get(i).toString();
        }
        System.out.println("The file has been read press P/p to print the file");
        return stringArray;
        
    }
    public void printEmployeeDetails() {
        for (int j=0;j<employeeList.size();j++) {
            System.out.println(employeeList.get(j));
        }
    }
    public void addEmployee(Scanner input) {

        System.out.println("Type (without quotations)'p' for project Leader or 't' for team leader: ");
        String designation = input.nextLine();
        System.out.print("Enter first name of the employee: ");
        String firstName = input.nextLine();
        System.out.print("Enter last name of the employee: ");
        String lastName = input.nextLine();
        System.out.print("Enter the ID of the employee: ");
        int employeeID = input.nextInt();
        System.out.print("Enter the salary of the employee: ");
        double yearlySalary = input.nextDouble();
        input.nextLine();
        if (designation.equalsIgnoreCase("p")) {
            designation = "Project Leader";
        }else if(designation.equalsIgnoreCase("t")){
            designation = "Team Leader";
        }
        Management employee;
        if (designation.equalsIgnoreCase("Project Leader")) {
            System.out.print("Enter the project name of the Project Leader: ");
            String projectName = input.nextLine();
            employee = new ProjectLeader(firstName, lastName, employeeID, yearlySalary,projectName);
        } else if (designation.equalsIgnoreCase("Team Leader")) {
            System.out.print("Enter team name of the Team Leader: ");
            String teamName = input.nextLine();
            employee = new TeamLeader(firstName, lastName, employeeID, yearlySalary, teamName);
        } else {
            System.out.println("Invalid designation. Employee not added.");
            return;
        }

        employeeList.add(employee);
    }
    public void monthlyPayroll() {
        for (Management employee : employeeList) {
            double monthlyNetSalary = (employee.getYearlySalary() / 12) * 0.8;
            System.out.println("Deposite "+ monthlyNetSalary+ "into "+ employee.getFirstName()+ " "+ employee.getLastName() + "'s bank account"); 
    }


}
}
