import java.util.Scanner;

public interface Employee {
    String toString();
    void addEmployee(Scanner input);
}