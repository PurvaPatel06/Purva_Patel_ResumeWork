import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * This class contains the dynamically allocated array and its processing
 * Student Name: Purva Patel
 * Student Number: 041094311
 * Course: CST8130 - Data Structures
 * CET-CS-Level 3
 * @Professor James Mwangi PhD. 
 */

public class Numbers {
    // Initialize scanner object for user input
    Scanner input = new Scanner(System.in);
    // Declare private instance variables
    private Float [] numbers;
    private int numItems;
    private int size = 0;

    // Constructor to initialize the array with a default size of 5
/**
 * @default Constructor 
 */
    public Numbers() {
        this.size = 5;
        // Create a new array of Float objects with the specified size
        numbers = new Float[size];
        // Initialize each element of the array with 0.0
        for(int k =0; k < numbers.length ; k++){
            numbers[k] = (float) 0.0;
        }
        // Initialize the number of items in the array to 0
        numItems = 0;
    }
    
    // Constructor to initialize the array with a specified size
    /**
     * @param size 
     */
    /**
     * Constructor to make new array of desired size.
     */
    public Numbers(int size) {
       if(size <= 0){
        System.out.println("Enter postive value greater than 0");
       }
       else {
        this.size = size;
        // Create a new array of Float objects with the specified size
        numbers = new Float[size];
        // Initialize the number of items in the array to 0
        numItems = 0;}
    }
    
    
    /** 
     * @param keyboard 
     */
    /**
     * Scanner to take the user input.
     */
    // Method to add a value to the array
    public void addValue(Scanner keyboard) {
        try {
            // Check if the array is not full
            if(numItems<size) {
                System.out.print("Enter value: ");
                // Read a float value from the user
                float value = keyboard.nextFloat();
                // Add the value to the array
                numbers[numItems] = value;
                // Increment the number of items in the array
                numItems++;
            } else {
                // Print error message if the array is full
                System.out.println("Array full");
            }
        } catch (InputMismatchException ie) {
            // Catch exception if user input is not a float
            System.err.println("Invalid input. Please enter a float value.");
            // Clear the input buffer
            keyboard.next();
        } catch (Exception e) {
            // Catch any other exceptions
            System.err.println(e);
            // Clear the input buffer
            keyboard.next();
        }
    }
    
    
    /** 
     * @param keyboard
     */
    /**
     * Add value option for file to avoid multiple miss-prints of "Enter Value:"
     */
    public void addValueForFile(Scanner keyboard) {
        try {
            // Check if the array is not full
            if(numItems<size) {
                // Read a float value from the user
                float value = keyboard.nextFloat();
                // Add the value to the array
                numbers[numItems] = value;
                // Increment the number of items in the array
                numItems++;
            } else {
                // Print error message if the array is full
                System.out.println("Array full");
            }
        } catch (InputMismatchException ie) {
            // Catch exception if user input is not a float
            System.err.println("Invalid input. Please enter a float value.");
            // Clear the input buffer
            keyboard.next();
        } catch (Exception e) {
            // Catch any other exceptions
            System.err.println(e);
            // Clear the input buffer
            keyboard.next();
        }
    }
    
    /** 
     * @return float
     */
    /**
     *Method to calculate the average of values in the array
     */
    // Method to calculate the average of values in the array
    public float calcAverage() {
        if (numItems == 0) {
            return (float) 0.0;
        }
        // Initialize sum variable
        float sum = 0;
        // Iterate through the array and calculate sum of values
        for(int i = 0; i < numItems ; i++) {
            sum += numbers[i];
        }
        // Calculate and return the average
        return sum / numItems;
    }
    /**
     * Method to find the minimum and maximum values in the array
     */
    public void findMinMax() {
        if (numItems == 0) {
            // Print default values if array is empty
            System.out.print(" Minimum value is "+ 0.0 + ", Maximum value is "+ 0.0 + ", max mod min value is "+ 0);
        }
        // Initialize min and max variables with the first value in the array
        float min = numbers[0];
        float max = numbers[0];
        // Iterate through the array to find min and max values
        for (int i = 1; i < numItems; i++) {
            if (numbers[i] < min) {
                min = numbers[i];
            }
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        // Print min, max, and max mod min values
        System.out.print(" Minimum value is "+ min + ", Maximum value is "+ max + ", max mod min value is "+ max % min);
    }
    /**
     * @return Factorial max number
     */
    /**
     * Method to find the minimum and maximum values in the array
     */
    public long getfactorialmax() {
        if (numItems == 0 ) {
            return 0;
        }
        // Initialize max variable with the first value in the array
        float max = numbers[0];
        // Find the maximum value in the array
        for (int i = 1; i < numItems; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        // Convert max value to an integer
        int maximum = (int) max;
        // Initialize factorial variable
        long factorial = 1;
        // Calculate factorial of the maximum value
        for (int i = 2; i <= maximum; i++) {
            factorial *= i;
        }
        // Return the factorial
        return factorial;
    }
    /**
     * Method to print number of values in an array
     */
    // Method to display values in the array
    public String toString() {
        System.out.println("numbers are:");
        for(int i = 0; i < numItems ; i++) {
            System.out.println(numbers[i] + ",");
        }
        // Return newline character
        return "\n";
    }
    /**
     * @param keyboard
     * @param numvalues
     */
    /**
     *Method to add multiple values in an existing array in one time.
     */
    public void enterMultipleValues(Scanner keyboard, int numvalues){
        if(numvalues + numItems > size){
            System.out.println("Array does not have enough space.");
        }
        else{
            for(int p = 0; p < numvalues; p++){
                System.out.println("Enter value: ");
                float value = keyboard.nextFloat();
                numbers[numItems] = value;
                numItems++;
            }
        }
    }
    /**
     * @param filename
     */
    /**
     *Method to read values from file
     */
    public void readValuesFromFile(String filename) {
        if(numItems<size) {
            try (Scanner fileScanner = new Scanner(new File(filename))) {
                fileScanner.next();
            while (fileScanner.hasNextFloat()) {
                addValueForFile(fileScanner);}
            }
            catch(FileNotFoundException fe){
                System.err.println(fe);
            }
            catch(InputMismatchException ie){
                System.err.println(ie);
            }
            catch(Exception e){
                System.err.println(e);
            }
        }
        else{
            System.out.println("Array is full");
        }
    }
    /**
     * @param filename
     */
    /**
     * Method to save values of existing array in a text file
     */
    public void saveValuestofile(String filename){
         try (PrintWriter writer = new PrintWriter(new File(filename))) {
            writer.println(numItems);
            for(int i =0; i < numItems; i++){
                writer.println(numbers[i]);
            }

         }catch(FileNotFoundException fe){
            System.err.println(fe);
         }
    }

}
