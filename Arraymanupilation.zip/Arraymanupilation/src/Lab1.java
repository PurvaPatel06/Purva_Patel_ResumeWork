import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * CET - CS Academic Level
 * This class contains the dynamically allocated array and its processing
 * Student Name: Purva Patel
 * Student Number: 041094311
 * Course: CST8130 - Data Structures
 * @Professor: James Mwangi PhD. 
 */
public class Lab1 {
    
    /** 
     * @param args
     * main method to run the program
     */
    public static void main(String[] args) {
        // Initialize scanner object for user input
        Scanner input = new Scanner(System.in);
        // Create an instance of the Numbers class to work with numbers
        Numbers numbers = new Numbers();
        // Boolean flag to control loop execution
        boolean con = true;
        // Variable to store user's choice
        int choice = 0;
        
        try {
            // Main loop to display menu and process user input
            do {
                // Display menu options to the user
                displayMenu();
                // Check if user input is an integer
                if (input.hasNextInt()) {
                    // Read user's choice
                    choice = input.nextInt();
                    // Switch statement to perform actions based on user's choice
                    switch (choice) {
                        case 1:
                            // Initialize a default array
                            numbers = new Numbers();
                            break;
                        case 2:
                            try {
                                // Specify the max size of the array
                                System.out.print("Enter value:");
                                int size = input.nextInt();
                                numbers = new Numbers(size);
                            } catch (InputMismatchException ie) {
                                // Catch exception if user input is not an integer
                                System.err.println("Please enter an integer");
                                // Clear the input buffer
                                input.next();
                            }
                            break;
                        case 3:
                            // Add value to the array
                            numbers.addValue(input);
                            break;
                        case 4:
                            // Display values in the array
                            numbers.toString();
                            break;
                        case 5:
                            // Display average of the values, minimum value, maximum value, max mod min, factorialMax
                            System.out.print("Average is: " + numbers.calcAverage());
                            numbers.findMinMax();
                            System.out.println(" Factorialmax is: " + numbers.getfactorialmax());
                            break;
                        case 6:
                        System.out.print("How many values do you wish to add? ");
                            int numValues = input.nextInt();
                            numbers.enterMultipleValues(input, numValues);
                            break;
                        case 7:
                            System.out.print("Name of the file to read from: ");
                            String readfile = input.next();
                            numbers.readValuesFromFile(readfile);
                            break;
                        case 8:
                            System.out.print("Name of the file to save to: ");
                            String saveFile = input.next();
                            numbers.saveValuestofile(saveFile);
                            break;
                        case 9:
                            // Exit the program
                            System.out.println("Exiting program.");
                            con = false;
                            break;
                        default:
                            //for any input other than 1 to 6
                        System.out.println("Please select a number between 1 to 9");
                            break;
                    }
                } else {
                    // Prompt user to enter an integer if input is not an integer
                    System.out.println("Please enter an integer.");
                    // Clear the input buffer
                    input.next();
                }
            } while (con); // Continue loop until user chooses to exit
        } catch (InputMismatchException ie) {
            // Catch any input mismatch exceptions
            System.err.println(ie);
        } catch (ArithmeticException ae) {
            // Catch any arithmetic exceptions
            System.err.println(ae);
        }
        
        // Close the scanner object to release resources
        input.close();
    }
    
    /**
     * @param null;
     * @return void
     */
    /**
     *Used to display menu in main method
     */
    public static void displayMenu() {
        System.out.println("Please select one of the following:");
        System.out.println("1: Initialize a default array");
        System.out.println("2: Specify the max size of the array");
        System.out.println("3: Add value to the array");
        System.out.println("4: Display values in the array");
        System.out.println("5: Display average of the values, minimum value, maximum value, max mod min, factorialMax");
        System.out.println("6: Enter multiple values");
        System.out.println("7: Read values from file");
        System.out.println("8: Save values to file");
        System.out.println("9: To Exit");
    }
}
