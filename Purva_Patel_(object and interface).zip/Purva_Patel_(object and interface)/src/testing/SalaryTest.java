/**
 * Program: CET Level 2
 * Student Name: Purva Patel
 * Student Number: 041094311
 * Course: CST8132_310 OOP
 * Professor: James Mwangi PhD.
 */

// Importing necessary libraries
package testing;
import application.FullTimeTechnician; // Importing FullTimeTechnician class from application package
import static org.junit.jupiter.api.Assertions.*; // Importing static methods from Assertions class in org.junit.jupiter.api package
import application.PartTimeTechnician; // Importing PartTimeTechnician class from application package
import org.junit.jupiter.api.Test; // Importing Test annotation from org.junit.jupiter.api package

// SalaryTest class
class SalaryTest {
    // Test method to test salary calculation for full-time technician
    @Test
    public void testFullTimeTechnicianSalary() {
        // Creating an instance of FullTimeTechnician with specified parameters
        FullTimeTechnician fullTimeTechnician = new FullTimeTechnician("Purva Patel", "FT1001", 900000.0);
        // Asserting that the calculated salary matches the expected value with a tolerance of 0.01
        assertEquals(900000.0, fullTimeTechnician.calculateSalary(), 0.00);
    }
    
    // Test method to test salary calculation for part-time technician
    @Test
    public void testPartTimeTechnicianSalary() {
        // Creating an instance of PartTimeTechnician with specified parameters
        PartTimeTechnician partTimeTechnician = new PartTimeTechnician("Ved Patel", "PT1001", 20.0);
        // Asserting that the calculated salary matches the expected value with a tolerance of 0.01
        assertEquals(750.0, partTimeTechnician.calculateSalary(), 0.00);
    }
}
