/**
 * Program: CET Level 2
 * Student Name: Purva Patel
 * Student Number: 041094311
 * Course: CST8132_310 OOP
 * Professor: James Mwangi PhD.
 */
package application;

// FullTimeTechnician class
public class FullTimeTechnician extends BaseTechnician {
    // Constructor
    public FullTimeTechnician(String name, String technicianId, double salary){
        super(name, technicianId, salary); // Calling superclass constructor to initialize instance variables
    }
    
    // Method to calculate salary for full-time technician
    public double calculateSalary(){
        return salary; // Returning the salary of the full-time technician
    }
    
    // Method to set salary for full-time technician
    public void setSalary(double salary){
        this.salary = salary; // Setting the salary of the full-time technician
    }
}
