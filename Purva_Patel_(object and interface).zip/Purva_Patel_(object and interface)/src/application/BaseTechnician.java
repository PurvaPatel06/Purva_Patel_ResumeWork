/**
 * Program: CET Level 2
 * Student Name: Purva Patel
 * Student Number: 041094311
 * Course: CST8132_310 OOP
 * Professor: James Mwangi PhD.
 */
package application;

// BaseTechnician class
public abstract class BaseTechnician implements TechDetail {
    // Instance variables
    protected String name; // Name of the technician
    protected String technicianId; // ID of the technician
    protected double salary; // Salary of the technician
    
    // Constructor
    public BaseTechnician(String name, String technicianId, double salary){
        // Initializing instance variables
        this.name = name; // Assigning value to name
        this.technicianId = technicianId; // Assigning value to technicianId
        this.salary = salary; // Assigning value to salary
    } 
    
    // Method to display technician details
    public void displayDetails(){
        // Printing technician details
        System.out.println("Technician ID: " + technicianId + // Displaying technician ID
                           "\n" + "Name: " + name + // Displaying technician name
                           "\n" + "Salary: " + salary); // Displaying technician salary
    }
}
