/**
 * Program: CET Level 2
 * Student Name: Purva Patel
 * Student Number: 041094311
 * Course: CST8132_310 OOP
 * Professor: James Mwangi PhD.
 */

// Importing necessary libraries
package application;
import java.util.ArrayList;

// TechnicianDriver class
public class TechnicianDriver {
    // Main method
    public static void main(String[] args) throws Exception {
        // Creating an instance of CSVReader class
        CSVReader csv = new CSVReader();
        
        // Reading technicians' data from CSV file into an ArrayList
        ArrayList<BaseTechnician> technicians = csv.readTechnicians("technicians.csv");
        
        // Iterating over each technician in the ArrayList
        for(BaseTechnician technician : technicians){
            // Displaying details of the technician
            technician.displayDetails();
            
            // Calculating and displaying the salary of the technician
            System.out.println("Calculated Salary: " + technician.calculateSalary());
            System.out.println();
        }
    }
}
