/**
 * Program: CET Level 2
 * Student Name: Purva Patel
 * Student Number: 041094311
 * Course: CST8132_310 OOP
 * Professor: James Mwangi PhD.
 */

// PartTimeTechnician class
package application;

// PartTimeTechnician class
public class PartTimeTechnician extends BaseTechnician {
    // Constructor
    public PartTimeTechnician(String name, String technicianId, double hourlyRate){
        super(name, technicianId, hourlyRate); // Calling superclass constructor to initialize instance variables
    }
    
    // Method to calculate salary for part-time technician
    public double calculateSalary(){
        return salary * 37.5; // Calculating salary based on hourly rate assuming 37.5 hours per week
    }
    
    // Method to set salary for part-time technician
    public void setSalary(double salary){
        this.salary = salary; // Setting the salary of the part-time technician
    }
}
