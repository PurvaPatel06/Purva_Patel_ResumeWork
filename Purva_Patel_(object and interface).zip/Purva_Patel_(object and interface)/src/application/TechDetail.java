/**
 * Program: CET Level 2
 * Student Name: Purva Patel
 * Student Number: 041094311
 * Course: CST8132_310 OOP
 * Professor: James Mwangi PhD.
 */

// TechDetail interface
package application;

// TechDetail interface
public interface TechDetail {
    // Method to display technician details
    void displayDetails();
    
    // Method to calculate salary
    double calculateSalary();
    
    // Method to set salary
    void setSalary(double salary);
}
