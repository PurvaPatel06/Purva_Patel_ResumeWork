/**

*Program: CET Level 2


*Student Name: Purva Patel

*Student Number:041094311

*Course: CST8132_310 OOP

*Professor: James Mwangi PhD.

*/
// Importing necessary libraries
// Importing necessary libraries
package application;
import java.io.BufferedReader; // Importing BufferedReader class to read text from a character-input stream
import java.io.FileReader; // Importing FileReader class to read character files
import java.io.IOException; // Importing IOException class to handle input/output errors
import java.util.ArrayList; // Importing ArrayList class to create an array list to store technicians' data

// CSVReader class
public class CSVReader {
    // Method to read technicians' data from CSV file
    public ArrayList<BaseTechnician> readTechnicians(String filePath) {
        // Creating an ArrayList to store technicians' data
        ArrayList<BaseTechnician> technicians = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("technicians.csv"))){
            // Reading each line from the CSV file
            String line;
            while((line = br.readLine())!=null){
                // Splitting each line into fields using comma as delimiter
                String[] value = line.split(",");
                // Extracting values from each field
                String availability = value[0]; // Extracting availability field
                String name = value[1]; // Extracting name field
                String technicianId = value[2]; // Extracting technician ID field
                double salary = Double.parseDouble(value[3]); // Extracting salary field and parsing it to double
                
                // Creating a BaseTechnician object based on availability
                BaseTechnician technician = null;
                if(availability.equalsIgnoreCase("FullTime")){
                    technician = new FullTimeTechnician(name,technicianId,salary); // Creating FullTimeTechnician object
                }
                else if(availability.equalsIgnoreCase("PartTime")){
                    technician = new PartTimeTechnician(name, technicianId, salary); // Creating PartTimeTechnician object
                }
                
                // Adding the technician object to the ArrayList
                technicians.add(technician);
            } 
        } catch (IOException e) {
            // Handling IO exception if encountered
            System.err.println("Error reading CSV file: " + e.getMessage());
        }
        // Returning the ArrayList containing technicians' data
        return technicians;
    }
}


