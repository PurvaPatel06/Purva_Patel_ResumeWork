import java.net.InetAddress; // Importing the InetAddress class for handling IP addresses
import java.net.UnknownHostException; // Importing UnknownHostException class for handling exceptions related to unknown hosts

public class SubnetCalculator {
    
    // Method to calculate subnet details
    public static void calcSubnet(String ipAddressStr){
        try {
            // Parse IPv4 address and subnet mask length from the input string
            InetAddress ipAddress = InetAddress.getByName(ipAddressStr.split("/")[0]); // Get InetAddress object for the given IP address
            int subnetMaskLength = Integer.parseInt(ipAddressStr.split("/")[1]); // Extract subnet mask length from the input string
            
            // Convert IP address bytes to integer representation
            byte[] ipAddBytes = ipAddress.getAddress(); // Get the bytes of the IP address
            int ipAddressInt = 0; // Initialize an integer variable to hold the IP address
            for(byte octet : ipAddBytes){ // Iterate over each byte of the IP address
                // Bitwise OR operation to construct the integer representation of the IP address
                ipAddressInt = (ipAddressInt << 8) | (octet & 0xff); // Shift the bits and combine with the next octet
            }
            
            // Calculate network and broadcast addresses
            int networkAddress = ipAddressInt & (0xffffffff << (32 - subnetMaskLength)); // Calculate network address using bitwise AND operation
            int broadcastAddress = networkAddress | ((1 << (32 - subnetMaskLength)) - 1); // Calculate broadcast address
            int subnetNumber = networkAddress & ~(32 - subnetMaskLength);
            int borrowedBits = 0; //calculate borrowed bits
            char subClass = 'A'; //determine the class of the network
            
            // Convert network and broadcast addresses to string format
            String networkAddressStr = intToIpAddress(networkAddress); // Convert network address to dot-decimal notation
            String broadcastAddressStr = intToIpAddress(broadcastAddress); // Convert broadcast address to dot-decimal notation
            String subnetnumString = intToIpAddress(subnetNumber);
            if (Integer.parseInt(networkAddressStr.split("\\.")[0]) >= 0 && Integer.parseInt(networkAddressStr.split("\\.")[0]) < 128) {
                subClass = 'A';
                borrowedBits = subnetMaskLength - 8;
            } else if (Integer.parseInt(networkAddressStr.split("\\.")[0]) >= 128 && Integer.parseInt(networkAddressStr.split("\\.")[0]) < 192) {
                subClass = 'B';
                borrowedBits = subnetMaskLength - 16;
            } else if (Integer.parseInt(networkAddressStr.split("\\.")[0]) >= 192 && Integer.parseInt(networkAddressStr.split("\\.")[0]) < 224) {
                subClass = 'C';
                borrowedBits = subnetMaskLength - 24;
            } else if (Integer.parseInt(networkAddressStr.split("\\.")[0]) >= 224 && Integer.parseInt(networkAddressStr.split("\\.")[0]) < 240) {
                subClass = 'D';
                borrowedBits = subnetMaskLength -28;
            } else if (Integer.parseInt(networkAddressStr.split("\\.")[0]) >= 240 && Integer.parseInt(networkAddressStr.split("\\.")[0]) <= 255) {
                subClass = 'E';
                borrowedBits = subnetMaskLength - 32;
            }
            // Calculate number of hosts
            int numHosts = (int) Math.pow(2, (32 - subnetMaskLength)) - 2; // Calculate number of usable hosts
            
            // Display subnet details
            System.out.println("Address:\t" + ipAddressStr + "\t\t" + formatBinary(Integer.toBinaryString(ipAddressInt))); // Print the input IP address and its binary representation
            System.out.println("Netmask:\t" + cidrToSubnetMask(subnetMaskLength) + " = " + subnetMaskLength + "\t" + formatBinary(Integer.toBinaryString(0xffffffff << (32 - subnetMaskLength)))); // Print subnet mask in dot-decimal notation and its binary representation
            System.out.println("Wildcard:\t0.0.0.255\t\t" + formatBinary(Integer.toBinaryString(0xff))); // Print wildcard mask and its binary representation
            System.out.println("=>\n"); // Print separator

            System.out.println("Number of bits borrowed: " + borrowedBits);
            System.out.println("Subnet Class: " + subClass);
            System.out.println("Subnet number:  " + subnetnumString + "\t\t" + formatBinary(Integer.toBinaryString(subnetNumber)));
            System.out.println("Network:\t" + networkAddressStr + "/" + subnetMaskLength + "\t\t" + formatBinary(Integer.toBinaryString(networkAddress))); // Print network address in dot-decimal notation and its binary representation
            System.out.println("Broadcast:\t" + broadcastAddressStr + "\t\t" + formatBinary(Integer.toBinaryString(broadcastAddress))); // Print broadcast address in dot-decimal notation and its binary representation
            System.out.println("HostMin:\t" + intToIpAddress(networkAddress + 1) + "\t\t" + formatBinary(Integer.toBinaryString(networkAddress + 1))); // Print minimum host IP address and its binary representation
            System.out.println("HostMax:\t" + intToIpAddress(broadcastAddress - 1) + "\t\t" + formatBinary(Integer.toBinaryString(broadcastAddress - 1))); // Print maximum host IP address and its binary representation
            System.out.println("Hosts/Net:\t" + numHosts); // Print number of usable hosts

        } catch (UnknownHostException e) {
            // Handle exception for invalid IPv4 address
            System.err.println("Error: Invalid IPv4 address");
        }
    }
    
    private static void elseif(boolean b) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'elseif'");
    }

    // Method to convert integer IP address to dot-decimal notation
    public static String intToIpAddress(int ipAddressInt) {
        // Convert each octet of the IP address to its decimal representation and concatenate them with periods
        return ((ipAddressInt >> 24) & 0xff) + "." +
               ((ipAddressInt >> 16) & 0xff) + "." +
               ((ipAddressInt >> 8) & 0xff) + "." +
               (ipAddressInt & 0xff);
    }
    
    // Method to convert CIDR notation to subnet mask in dot-decimal notation
    public static String cidrToSubnetMask(int cidr) {
        // Construct the subnet mask by left shifting 0xffffffff by the number of bits to set to 0
        return intToIpAddress(0xffffffff << (32 - cidr));
    }
    
    // Method to format binary string representing IP addresses
    public static String formatBinary(String binaryString) {
        // Format the binary string to represent IP addresses with periods every 8 bits
        StringBuilder formattedString = new StringBuilder();
        for (int i = 0; i < binaryString.length(); i++) {
            if (i > 0 && i % 8 == 0) { // Add a period after every 8 bits
                formattedString.append(".");
            }
            formattedString.append(binaryString.charAt(i)); // Append the current bit
        }
        return formattedString.toString();
    }
}
