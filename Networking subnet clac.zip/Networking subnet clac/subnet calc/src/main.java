import java.util.Scanner; // Importing Scanner class for user input

public class main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); // Creating Scanner object for user input
        SubnetCalculator sbc = new SubnetCalculator(); // Creating SubnetCalculator object
        
        char choice; // Variable to store user's choice
        do {
            // Prompting user for input
            System.out.println("Press 'e' to enter an IP address or press 'q' to quit the program");
            choice = input.next().charAt(0); // Reading user's choice
            input.nextLine(); // Clearing the input buffer
            
            // Handling user's choice
            switch (choice) {
                case 'e':
                    System.out.print("Enter IP address with mask (e.g., 202.168.0.1/24): ");
                    String ipAddress = input.nextLine(); // Reading IP address from user input
                    sbc.calcSubnet(ipAddress); // Calculating and displaying subnet details
                    break;
                case 'q':
                    System.out.println("Exiting..."); // Informing user about program termination
                    break;
                default:
                    System.out.println("Invalid choice"); // Informing user about invalid choice
                    break;
            }
        } while (choice != 'q'); // Loop until user chooses to quit
        input.close(); // Closing Scanner object
    }
}
